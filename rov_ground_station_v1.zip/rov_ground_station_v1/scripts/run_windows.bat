@echo off
setlocal EnableExtensions
:: ==============================================================================
:: ROV Telemetry Ground Station - Windows Launcher (Double-Click to Run)
:: Compatible with Windows 10 and Windows 11
:: ==============================================================================
title ROV Ground Station - Nagarjuna Sagar Dam Inspection

cd /d "%~dp0\.."

echo ============================================================
echo  Starting ROV Ground Station (Windows)
echo ============================================================

:: Verify Python installation (supports python, py launcher, and Windows 10/11 aliases)
set "PYTHON_CMD="
python -c "import sys; sys.exit(0)" >nul 2>&1
if not errorlevel 1 (
    set "PYTHON_CMD=python"
) else (
    py -3 -c "import sys; sys.exit(0)" >nul 2>&1
    if not errorlevel 1 (
        set "PYTHON_CMD=py -3"
    )
)

if "%PYTHON_CMD%"=="" (
    echo [ERROR] Python 3 was not found in your system PATH.
    echo Please install Python 3.10+ from https://www.python.org/
    echo Make sure to check "Add python.exe to PATH" during installation.
    echo.
    pause
    exit /b 1
)

:: Check if virtual environment already exists and is valid
if exist "venv\Scripts\python.exe" goto launch_app

echo [SETUP] Creating isolated virtual environment 'venv'...
%PYTHON_CMD% -m venv venv
if errorlevel 1 (
    echo [ERROR] Failed to create virtual environment.
    echo Please check Python installation and permissions.
    echo.
    pause
    exit /b 1
)

echo [SETUP] Installing required libraries: PySide6, pyqtgraph, numpy...
venv\Scripts\python.exe -m pip install --no-cache-dir -r scripts\requirements.txt
if errorlevel 1 (
    echo [ERROR] Failed to install required dependencies.
    echo Please check your internet connection and try again.
    echo.
    pause
    exit /b 1
)

:launch_app
echo [LAUNCH] Launching ROV Telemetry Dashboard...
venv\Scripts\python.exe main.py
if errorlevel 1 (
    echo.
    echo [ERROR] Application encountered an error (exit code %ERRORLEVEL%).
    pause
    exit /b %ERRORLEVEL%
)

exit /b 0


